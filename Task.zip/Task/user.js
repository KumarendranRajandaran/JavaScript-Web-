function addRow()

{

    var increment = document.getElementById('UserID').value;
    increment++;
    document.getElementById('UserID').value = increment;

  //get input values
  var UserID = document.getElementById('UserID').value;
  var UserName = document.getElementById('UserName').value;
  var UserOccupation = document.getElementById('UserOccupation').value;

  //get the html table
  var table = document.getElementsByTagName('table')[0];

  var newRow = table.insertRow(table.rows.length);

  var cel1 = newRow.insertCell(0);
  var cel2 = newRow.insertCell(1);
  var cel3 = newRow.insertCell(2);

  cel1.innerHTML = UserID;
  cel2.innerHTML = UserName;
  cel3.innerHTML = UserOccupation;
}
